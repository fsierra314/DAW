let input = document.getElementById("input-box");
let button = document.getElementById("submit-button");
let buttonV = document.getElementById("ver-mas");
let buttonD = document.getElementById("ver-des");
let showContainer = document.getElementById("show-container");
let listContainer = document.querySelector(".list");
let showComics = document.getElementById("show-comics");

let date = new Date();
console.log(date.getTime());

const [timestamp, apiKey, hashValue] = [ts, publicKey, hashVal];    

input.addEventListener("keyup", async () => {
  removeElements();

  const url = `https://gateway.marvel.com:443/v1/public/characters?ts=${timestamp}&apikey=${apiKey}&hash=${hashValue}&nameStartsWith=${input.value}`;

  const response = await fetch(url);
  const jsonData = await response.json();

  jsonData.data["results"].forEach((result) => {
    let name = result.name;
    let word = "<b>" + name.substr(0, input.value.length) + "</b>";
    word += name.substr(input.value.length);
    div.innerHTML = `<p class="item">${word}</p>`;
    listContainer.appendChild(div);
  });
});

button.addEventListener(
  "click",
  (getRsult = async () => {
    showContainer.innerHTML = "";
    const url = `https://gateway.marvel.com:443/v1/public/characters?ts=${timestamp}&apikey=${apiKey}&hash=${hashValue}&name=${input.value}`;

    const response = await fetch(url);
    const jsonData = await response.json();
    jsonData.data["results"].forEach((element) => {
      showContainer.innerHTML = `<div class="card-container">
        <div class="container-character-image">
        <img src="${
          element.thumbnail["path"] + "." + element.thumbnail["extension"]
        }"/></div>
        <div class="character-name">${element.name}</div>
        <div class="character-description">${element.description}</div>
        </div>`;
    });
  })
);

buttonV.addEventListener(
    "click",
    (getRsult = async () => {
      showContainer.innerHTML = "";
      const url = `https://gateway.marvel.com:443/v1/public/characters?ts=${timestamp}&apikey=${apiKey}&hash=${hashValue}&name=${input.value}`;
  
      const response = await fetch(url);
      const jsonData = await response.json();
      jsonData.data["results"].forEach((element) => {
        showContainer.innerHTML = `<div class="card-container">
          <div class="container-character-image">
          <img src="${
            element.thumbnail["path"] + "." + element.thumbnail["extension"]
          }"/></div>
          <div class="character-comics"><br><b>Cantidad de comics:</b> ${element.comics.available}</div>
          <div class="character-comics"><b>Cantidad de series:</b> ${element.series.available}</div>
          <div class="character-comics"><b>Cantidad de stories:</b> ${element.stories.available}</div>
          <div class="character-comics"><b>Cantidad de events:</b> ${element.events.available}</div>
          <div class="character-comics"><br><b>Primera serie:</b> ${element.series.items[0].name}</div>
          <div class="character-comics"><b>Segunda serie:</b> ${element.series.items[1].name}</div>
          <div class="character-comics"><b>Segunda serie:</b> ${element.series.items[2].name}</div>
          </div>`;
      });
    })
  );

  buttonD.addEventListener(
    "click",
    (getRsult = async () => {
      showContainer.innerHTML = "";
      const url = `https://gateway.marvel.com:443/v1/public/characters?ts=${timestamp}&apikey=${apiKey}&hash=${hashValue}&name=${input.value}`;
  
      const response = await fetch(url);
      const jsonData = await response.json();
      jsonData.data["results"].forEach((element) => {
        showContainer.innerHTML = `<div class="card-container">
          <div class="container-character-image">
          <img src="${
            element.thumbnail["path"] + "." + element.thumbnail["extension"]
          }"/></div>
          <div class="character-name">${element.name}</div>
          <div class="character-description">${element.description}</div>
          </div>`;
      });
    })
  );

window.onload = () => {
  getRsult();
};